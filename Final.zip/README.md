# Aufgaben von Linus Schumann
**Teilnahme-ID: 66432**

**Team-ID: 00662**

**Letze Änderung: 20.11.22**

## Bearbeitete Aufgaben:
* Aufgabe 1
* Aufgabe 2
* Aufgabe 4
* Aufgabe 5

## Inhalt einer Aufgabe:
* source: Alle C++/Python Quelltextdateien
* beispieldaten: Alle verwendeten Beispieldaten aus der Dokumentation
* beispielausgaben: Alle Ausgaben der Beispieldaten
* executable:
  * Bei C++-Implementierung ausführbare .exe Datei
  * Batch-Datei zum Starten des Programms 